const ICONTYPES = {
  LOADER: "loader",
  MENU: "menu",
  USERS: "users",
  STORE: "store",
  STAR: "star",
  CLOSE: "close",
  USER: "user",
  SHOWPS: "showps",
  HIDEPS: "hideps",
  ERROR: "error",
};

export default ICONTYPES;
