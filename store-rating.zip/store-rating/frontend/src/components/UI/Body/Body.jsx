import React from "react";

const Body = ({ children }) => {
  return <div className=" min-h-[calc(100vh-6rem)] ">{children}</div>;
};

export default Body;
