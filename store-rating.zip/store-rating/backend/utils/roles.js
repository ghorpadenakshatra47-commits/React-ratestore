const roles = {
  ADMIN: "system-admin",
  USER: "normal-user",
  STOREOW: "store-owner",
};
export default roles;
